# Perez Advogados Associados — Site

## O que causou o erro no GitHub Actions

O log do job "pages build and deployment" mostra:

```
github-pages 232 | Error: No such file or directory @ dir_chdir0 - /github/workspace/docs
```

Isso significa que, em **Settings → Pages → Build and deployment**, a origem
("Source") do seu repositório está configurada para publicar a partir da
pasta `/docs`, mas essa pasta não existia no repositório (ou estava vazia).
O Jekyll (motor padrão do GitHub Pages) tentou entrar em `/docs` e falhou.

## O que este pacote já resolve

- `index.html` — o site pronto, na raiz do repositório.
- `docs/index.html` — a mesma versão, dentro de `/docs`, para o caso de você
  preferir manter essa opção marcada no GitHub.
- `.nojekyll` (na raiz e dentro de `/docs`) — arquivo vazio que instrui o
  GitHub Pages a **não** rodar o Jekyll. Como este é um site estático puro
  (HTML/CSS/JS, sem Markdown, sem tema Jekyll), isso evita esse tipo de erro
  no futuro.

## Como publicar

1. Copie o conteúdo desta pasta para a raiz do seu repositório `Sites`
   (ou substitua os arquivos existentes).
2. Faça commit e push:
   ```
   git add .
   git commit -m "Novo site Perez Advogados Associados"
   git push
   ```
3. No GitHub, vá em **Settings → Pages → Build and deployment**:
   - Source: **Deploy from a branch**
   - Branch: `main` (ou a branch que você usa)
   - Folder: escolha **`/ (root)`** se for usar o `index.html` da raiz,
     **ou** **`/docs`** se preferir manter essa opção — os dois já estão
     prontos e idênticos neste pacote.
4. Salve. O deploy deve rodar novamente e concluir com sucesso em 1–2 minutos.

## Observação sobre "Casos Midiáticos"

Adicionei a seção e o link de navegação "Casos Midiáticos" pedidos, mas
deixei um espaço reservado — não inventei matérias ou resultados de casos,
já que isso é conteúdo sensível para publicidade de advogado (regras da
OAB). Basta me enviar os links/textos reais das matérias que eu insiro no
mesmo estilo visual.

Da mesma forma, mantive apenas o livro "Prática Processual Penal", que é
real e confirmado. O segundo "livro" que aparecia no site em base44.app
tinha conteúdo de exemplo (placeholder) do próprio template — me envie os
dados reais da segunda publicação, se houver, para eu adicionar.
